package homeWorks.homeWork_13.player;

public interface Playable {
    String trackName = "";
    void play(String name);
    void pause();
    void stop();
}
