package homeWorks.homeWork_13.player;

public interface Recordable {
    String trackName = "";
    void record();
    void pause();
    void stop();
}
